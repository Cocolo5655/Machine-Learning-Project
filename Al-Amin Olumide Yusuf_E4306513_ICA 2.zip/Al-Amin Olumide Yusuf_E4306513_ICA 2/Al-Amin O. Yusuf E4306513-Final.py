#!/usr/bin/env python
# coding: utf-8

# # INTRODUCTION
I will be working on a loan approval dataset obtained from https://www.kaggle.com/datasets/architsharma01/loan-approval-prediction-dataset/data
It has 13 Columns and 4269 Rows.
# In[182]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.style as style
import random
import seaborn as sns
import warnings
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split,GridSearchCV,cross_val_score,KFold
from sklearn.feature_selection import SequentialFeatureSelector as sfs,RFE
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,precision_score, recall_score, f1_score
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif
from sklearn.model_selection import GridSearchCV
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import roc_curve, roc_auc_score, auc
from sklearn.utils import resample
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.feature_selection import RFE
from imblearn.pipeline import Pipeline 
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from collections import Counter
from scipy import stats
from imblearn.over_sampling import RandomOverSampler
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score, make_scorer


# In[183]:


#Load Datset
df= pd.read_csv('loan_approval_dataset.csv')


# In[184]:


# Print Dataset
df


# # DATA STRUCTURE
The Data Structure will explore the dataset by displaying sample rows, checking column names, and reviewing data types.  
# In[186]:


#Delete the space in the columns string
df.columns = df.columns.str.strip()


# In[187]:


#Showing the first ten values
df.head(10)


# In[188]:


##Shape of the dataset
df.shape


# In[189]:


##Size of the data
df.size


# In[190]:


##Data information
df.info()


# # PREPARATION OF DATA
Data Preparation will involve handling missing values, duplicates, and any necessary data cleaning to ensure consistency.  
# In[192]:


#Checking for duplicates
df.duplicated().sum()


# In[193]:


##Checking for missing values
df.isna().sum()


# In[194]:


##Describing the dataset
df.describe()


# In[195]:


#Transposed dataset
df.describe().T


# In[196]:


##Checking data types
df.dtypes


# # EXPLORATORY DATA ANALYSIS
In Exploratory Data Analysis (EDA), the dataset will be visually analyzed using charts and graphs to identify patterns, distributions, and potential outliers.  
# In[198]:


df.columns


# In[199]:


numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
print("Numerical Columns:", numerical_cols)


# In[200]:


outlier_counts = {}
for col in numerical_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
    outlier_counts[col] = len(outliers)


# In[201]:


# Print outlier counts before removal
print("Outlier counts before removal:")
for col, count in outlier_counts.items():
    print(f"Column: {col}, Outliers: {count}")


# In[202]:


# Visualize outliers using boxplots before removal
plt.figure(figsize=(12, 6))
df[numerical_cols].boxplot(rot=45)
plt.title("Boxplot of Numerical Columns Before Removing Outliers")
plt.show()


# In[203]:


# Remove outliers using stricter Z-score (threshold = 2)
z_scores = np.abs(stats.zscore(df[numerical_cols]))
df_cleaned = df[(z_scores < 2).all(axis=1)]

# Apply IQR method to remove remaining outliers
for col in numerical_cols:
    Q1 = df_cleaned[col].quantile(0.25)
    Q3 = df_cleaned[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    df_cleaned = df_cleaned[(df_cleaned[col] >= lower_bound) & (df_cleaned[col] <= upper_bound)]


# In[204]:


# Visualize outliers using boxplots after removal
plt.figure(figsize=(12, 6))
df_cleaned[numerical_cols].boxplot(rot=45)
plt.title("Boxplot of Numerical Columns After Removing Outliers")
plt.show()


# In[205]:


# Print outlier counts after removal
outlier_counts_after = {}
for col in numerical_cols:
    Q1 = df_cleaned[col].quantile(0.25)
    Q3 = df_cleaned[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = df_cleaned[(df_cleaned[col] < lower_bound) | (df_cleaned[col] > upper_bound)]
    outlier_counts_after[col] = len(outliers)

print("Outlier counts after removal:")
for col, count in outlier_counts_after.items():
    print(f"Column: {col}, Outliers: {count}")


# In[206]:


print("Sum of Unique Values in Numerical Columns After Removing Outliers:")
for col in numerical_cols:
    print(f"Column: {col}, Unique Values: {df_cleaned[col].nunique()}")


# In[207]:


plt.figure(figsize=(15, 10))
for i, col in enumerate(df_cleaned.columns[:12], 1):
    plt.subplot(3, 4, i)
    sns.histplot(df_cleaned[col], kde=True)
    plt.title(f'Distribution of {col}')
plt.tight_layout()
plt.show()


# In[317]:


numerical_columns = df_cleaned.select_dtypes(include=['float64', 'int64']).columns
target_variable = "loan_status"

plt.figure(figsize=(20, 10))

for i, col in enumerate(numerical_columns, 1):
    plt.subplot(4, 4, i)
    sns.histplot(data=df_cleaned, x=col, hue=target_variable, kde=True)
    plt.title(f"Distribution of {col} by {target_variable}")
    plt.xlabel(col)
    plt.ylabel("Count")

plt.tight_layout()
plt.savefig("Histplot.jpg")
plt.show()


# In[209]:


plt.figure(figsize=(15, 10))

for i, col in enumerate(numerical_columns, 1):
    plt.subplot(4, 4, i)
    sns.boxplot(x='loan_status', y=col, data=df_cleaned)
    plt.title(f"Boxplot of {col} by Loan Status")
    plt.xlabel("Loan Status")
    plt.ylabel(col)

plt.tight_layout()
plt.savefig("Boxplot")
plt.show()


# In[210]:


# Scatterplot for cibil_score
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df_cleaned, x='cibil_score', y='loan_amount', hue='loan_status', alpha=0.6)
plt.title('Loan Amount vs Cibil Score')
plt.xlabel('Civil Score')
plt.ylabel('Loan Amount')
plt.legend(title='Loan Status')
plt.show()


# In[211]:


# Count plot for loan status
plt.figure(figsize=(8, 6))
sns.countplot(data=df, x='loan_status', palette='coolwarm',hue='loan_status',legend=True)
plt.title("Loan Status Distribution")
plt.xlabel("Loan Status")
plt.ylabel("Count")
plt.show()


# In[212]:


# Correlation matrix for numerical columns
numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
plt.figure(figsize=(12, 8))
sns.heatmap(df[numerical_cols].corr(), annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title("Correlation Matrix for Numerical Columns")
plt.show()


# In[213]:


numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns.drop('luxury_assets_value', errors='ignore')
plt.figure(figsize=(12, 8))
sns.heatmap(df[numerical_cols].corr(), annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title("Correlation Matrix for Numerical Columns")
plt.show()


# # FEATURE ENGINEERING
This section will focus on modifying or creating new features to improve model performance, including encoding categorical variables.  
# In[215]:


df_cleaned = df.drop(columns=['loan_id'], errors='ignore')


# In[216]:


df_cleaned


# In[217]:


df_cleaned.info()


# In[218]:


df_cleaned.head()


# In[219]:


df_cleaned.tail()


# In[220]:


df_cleaned.isna().sum()


# In[221]:


df_cleaned.columns


# # ENCODING

# In[223]:


categorical_cols = df_cleaned.select_dtypes(include=['object']).columns
df_cleaned[categorical_cols] = df_cleaned[categorical_cols].apply(lambda x: x.astype('category').cat.codes)


# In[224]:


# Split data into features (x) and target (y)
x = df_cleaned.drop(columns=['loan_status'])
y = df_cleaned['loan_status']
#Save features before resampling
feature_names = x.columns.tolist()

# Split into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42, stratify=y)


# # FEATURE SCALING
In this section, statistical methods will be used to identify the most relevant features for model training.  
# In[226]:


# Scale the dataset
scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)
x_test_scaled = scaler.transform(x_test)


# In[227]:


print("Training Data Head:")
display(pd.DataFrame(x_train_scaled, columns=x.columns).head())
print("\nTesting Data Head:")
display(pd.DataFrame(x_test_scaled, columns=x.columns).head())


# In[228]:


# Perform ANOVA F-value test and select top 10 features
selector = SelectKBest(score_func=f_classif, k=10)
x_train_selected = selector.fit_transform(x_train_scaled, y_train)
x_test_selected = selector.transform(x_test_scaled)
selected_features = x.columns[selector.get_support()]


# In[229]:


# Create a DataFrame for feature importance
feature_scores = pd.DataFrame({'Feature': x.columns, 'Score': selector.scores_})
feature_scores = feature_scores.sort_values(by='Score', ascending=False)
print("Feature Importance:")
print(feature_scores)


# In[230]:


# Plot feature importance
plt.figure(figsize=(12, 6))
sns.barplot(x=feature_scores['Score'], y=feature_scores['Feature'], palette='viridis',hue=feature_scores['Score'], legend=False)
plt.title("Feature Importance based on ANOVA F-value")
plt.xlabel("F-Score")
plt.ylabel("Features")
plt.show()


# # MODEL IMPLEMENTATION
The Model Implementation section will introduce the four machine learning models that will be trained and evaluated to predict outcomes.  
# In[232]:


# Define models
models = {
    "Random Forest": RandomForestClassifier(random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=500, solver='saga', random_state=42),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Naive Bayes": GaussianNB()
}


# In[233]:


# Train models, display classification reports, and print confusion matrices
train_accuracies = {}
test_accuracies = {}
for name, model in models.items():
    model.fit(x_train_scaled, y_train)
    y_pred_train = model.predict(x_train_scaled)
    y_pred_test = model.predict(x_test_scaled)
    train_accuracies[name] = accuracy_score(y_train, y_pred_train)
    test_accuracies[name] = accuracy_score(y_test, y_pred_test)
    
    print(f"\n{name} Classification Report:")
    print(classification_report(y_test, y_pred_test))
    
    # Print Confusion Matrix
    print(f"\n{name} Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred_test))


# In[234]:


plt.figure(figsize=(10, 6))
sns.barplot(x=list(train_accuracies.keys()), y=list(train_accuracies.values()), palette='viridis', hue=list(train_accuracies.keys()),legend =False)
plt.title("Training Accuracy of Models")
plt.xlabel("Models")
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.xticks(rotation=45)
plt.savefig("Training Accuracy of Models.jpg")
plt.show()


# In[235]:


# Visualize test accuracy
plt.figure(figsize=(10, 6))
sns.barplot(x=list(test_accuracies.keys()), y=list(test_accuracies.values()), palette='magma',hue=list(train_accuracies.keys()),legend =False)
plt.title("Test Accuracy of Models")
plt.xlabel("Models")
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.xticks(rotation=45)
plt.savefig("Testing Accuracy of Models.jpg")
plt.show()


# In[236]:


# Display summary of performance
performance_summary = pd.DataFrame({
    "Model": list(models.keys()),
    "Training Accuracy": list(train_accuracies.values()),
    "Test Accuracy": list(test_accuracies.values())
})
print("\nPerformance Summary:")
print(performance_summary)


# In[237]:


# Draw ROC Curve for all models
plt.figure(figsize=(10, 6))
for name, model in models.items():
    y_prob = model.predict_proba(x_test_scaled)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    auc_score = auc(fpr, tpr)
    plt.plot(fpr, tpr, label=f'{name} (AUC = {auc_score:.2f})')

plt.plot([0, 1], [0, 1], linestyle='--', color='gray')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve for Model Performance")
plt.legend()
plt.savefig("Roc Models.jpg")
plt.show()


# # MODEL OPTIMISATION
In this section, techniques like cross-validation and hyperparameter tuning will be applied to improve model accuracy and generalization.  
# In[239]:


# Resample the target variable to balance the dataset
ros = RandomOverSampler(random_state=42)
x_resampled, y_resampled = ros.fit_resample(x_train_scaled, y_train)


# In[240]:


# Plot distribution before resampling
plt.figure(figsize=(6, 4))
sns.countplot(x=y_train, palette='coolwarm',hue=y_train, legend=True)
plt.title("Class Distribution Before Resampling")
plt.xlabel("Loan Status")
plt.ylabel("Count")
plt.savefig("Training Accuracy of Models before.jpg")
plt.show()


# In[241]:


# Plot distribution after resampling
plt.figure(figsize=(6, 4))
sns.countplot(x=y_resampled, palette='coolwarm',hue=y_resampled, legend=True)
plt.title("Class Distribution After Resampling")
plt.xlabel("Loan Status")
plt.ylabel("Count")
plt.savefig("Training Accuracy of Models after.jpg")
plt.show()


# In[242]:


# Define models
models = {
    "Random Forest": RandomForestClassifier(random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=500, solver='saga', random_state=42),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Naive Bayes": GaussianNB()
}


# In[243]:


# Perform K-fold cross-validation for each model
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_results = {}
for name, model in models.items():
    scores = cross_val_score(model, x_resampled, y_resampled, cv=kf, scoring='accuracy')
    cv_results[name] = scores
    print(f"\n{name} 5-Fold Cross-Validation Accuracies: {scores}")
    print(f"{name} Mean Accuracy: {scores.mean():.4f} (+/- {scores.std():.4f})")
    model.fit(x_resampled, y_resampled)
    y_pred_kfold = model.predict(x_test_scaled)
    print(f"\nClassification Report for {name} (K-Fold CV):\n{classification_report(y_test, y_pred_kfold)}")


# In[244]:


# Define hyperparameter search space
hyperparameter_grid = {
    "Random Forest": {
        "n_estimators": [50, 100, 200],
        "max_depth": [None, 10, 20],
        "min_samples_split": [2, 5, 10]
    },
    "Logistic Regression": {
        "C": [0.01, 0.1, 1, 10],
        "solver": ["lbfgs", "saga"]
    },
    "Decision Tree": {
        "max_depth": [None, 5, 10, 20],
        "min_samples_split": [2, 5, 10]
    },
    "Naive Bayes": {}
}

# Implement GridSearchCV
warnings.filterwarnings('ignore')

# Use accuracy_score as the scoring function
accuracy = make_scorer(accuracy_score)

grid_search_results = {}
kfold_cv_mean_scores = {}


for name, model in models.items():
    print(f"Tuning hyperparameters for {name}...")
    # Get the hyperparameter grid for the current model
    param_grid = hyperparameter_grid.get(name, {})

    # Instantiate GridSearchCV
    grid_search = GridSearchCV(model, param_grid, cv=kf, scoring='accuracy', verbose=0, n_jobs=-1)  # Use n_jobs=-1 for parallel processing

    # Fit GridSearchCV to the data
    grid_search.fit(x_resampled, y_resampled)

    # Store the best model and results
    cv_results[name] = {
        'best_score': grid_search.best_score_,
        'best_params': grid_search.best_params_,
        'best_estimator': grid_search.best_estimator_
    }

    print(f"{name} Best Accuracy: {grid_search.best_score_:.4f}")
    print(f"{name} Best Parameters: {grid_search.best_params_}")

for name, result in cv_results.items():
    best_estimator = result['best_estimator']
    y_pred = best_estimator.predict(x_test_scaled)
    print(f"\nClassification Report for {name}:\n{classification_report(y_test, y_pred)}")


# In[245]:


# Dictionaries to store results
kfold_results = {}
gridsearch_results = {}

# Loop through models and evaluate
for name, model in models.items():
    # K-Fold Cross-Validation Evaluation
    model.fit(x_resampled, y_resampled)
    y_pred_kfold = model.predict(x_test_scaled)
    report_kfold = classification_report(y_test, y_pred_kfold, output_dict=True)
    kfold_results[name] = {
        "Precision": report_kfold["weighted avg"]["precision"],
        "Recall": report_kfold["weighted avg"]["recall"],
        "F1-Score": report_kfold["weighted avg"]["f1-score"]
    }
    
    # GridSearchCV Evaluation 
    best_model = grid_search.best_estimator_  
    y_pred_grid = best_model.predict(x_test_scaled)
    report_grid = classification_report(y_test, y_pred_grid, output_dict=True)
    gridsearch_results[name] = {
        "Precision": report_grid["weighted avg"]["precision"],
        "Recall": report_grid["weighted avg"]["recall"],
        "F1-Score": report_grid["weighted avg"]["f1-score"]
    }

# Convert results to DataFrame for better visualization
kfold_df = pd.DataFrame(kfold_results).T
gridsearch_df = pd.DataFrame(gridsearch_results).T
comparison_df = kfold_df.join(gridsearch_df, lsuffix="_KFold", rsuffix="_GridSearch")

print("\nComparison of Classification Reports (K-Fold vs. GridSearchCV)")
display(comparison_df)

K-Fold outperformed grid search so the models will be trained using k-fold
# In[246]:


# Define K-Fold Cross-Validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# Dictionary to store final model results
final_model_results = {}
best_models={}

# Train and evaluate each model using K-Fold
for name, model in models.items():
    scores = cross_val_score(model, x_resampled, y_resampled, cv=kf, scoring='accuracy')
    
    # Train final model on full dataset
    model.fit(x_resampled, y_resampled)
    train_accuracy = model.score(x_resampled, y_resampled)
    test_accuracy = model.score(x_test_scaled, y_test)
    y_pred_final = model.predict(x_test_scaled)
    report_final = classification_report(y_test, y_pred_final, output_dict=True)
    conf_matrix = confusion_matrix(y_test, y_pred_final)

    best_models[name] = model
    # Store results
    final_model_results[name] = {
        "Train Accuracy": train_accuracy,
        "Test Accuracy": test_accuracy,
        "Mean CV Accuracy": scores.mean(),
        "Std Dev CV Accuracy": scores.std(),
        "Precision": report_final["weighted avg"]["precision"],
        "Recall": report_final["weighted avg"]["recall"],
        "F1-Score": report_final["weighted avg"]["f1-score"],
        "Confusion Matrix": conf_matrix
        
    }

# Convert final results to DataFrame 
final_results_df = pd.DataFrame(final_model_results).T.drop(columns=["Confusion Matrix"])




# Print final results
print("\nFinal Model Evaluation using K-Fold Cross-Validation")
print(final_results_df)

# Print confusion matrices separately
for name, results in final_model_results.items():
    print(f"\nConfusion Matrix for {name}:")
    print(results["Confusion Matrix"])



# In[247]:


# Plot Training vs. Testing Accuracy 
plt.figure(figsize=(10, 6))
train_data = pd.DataFrame({"Model": final_results_df.index, "Accuracy": final_results_df["Train Accuracy"], "Type": "Train Accuracy"})
test_data = pd.DataFrame({"Model": final_results_df.index, "Accuracy": final_results_df["Test Accuracy"], "Type": "Test Accuracy"})
plot_data = pd.concat([train_data, test_data])

sns.histplot(data=plot_data, x="Model", hue="Type", weights="Accuracy", multiple="dodge", shrink=0.8, kde=False, palette={"Train Accuracy": "blue", "Test Accuracy": "orange"})

plt.xlabel("Models")
plt.ylabel("Accuracy")
plt.title("Comparison of Training and Testing Accuracy")
plt.xticks(rotation=45)
plt.legend(title="Accuracy Type")
plt.show()
plt.show()


# In[248]:


plt.figure(figsize=(10, 6))
for name, model in best_models.items():
    y_prob = model.predict_proba(x_test_scaled)[:, 1] if hasattr(model, "predict_proba") else np.zeros_like(y_test)
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    auc_score = auc(fpr, tpr)
    plt.plot(fpr, tpr, label=f'{name} (AUC = {auc_score:.2f})')

plt.plot([0, 1], [0, 1], linestyle='--', color='gray')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve for Model Performance")
plt.legend()
plt.show()


# # FEATURE IMPORTANCE
The Feature Importance section will analyze which features contribute most to the model’s predictions.  
# In[250]:


if "Random Forest" in best_models:
    rf_model = best_models["Random Forest"]
    feature_importances = rf_model.feature_importances_


# In[251]:


feature_importance_df = pd.DataFrame({
    "Feature": feature_names,
    "Importance": feature_importances
})
feature_importance_df = feature_importance_df.sort_values(by="Importance", ascending=False)

# Print feature importance table
print("\nFeature Importance for Random Forest:")
display(feature_importance_df) 


# In[325]:


sns.barplot(x=feature_importances, y=feature_names, color='blue')
plt.title("Random Forest Feature Importance")
plt.xlabel("Importance")
plt.ylabel("Features")
plt.tight_layout()
plt.savefig("Feature Importance.jpg")
plt.show()

