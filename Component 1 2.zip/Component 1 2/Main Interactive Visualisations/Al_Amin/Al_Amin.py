import pandas as pd
from collections import defaultdict

# Load CSV file
df = pd.read_csv("heart_disease.csv")

# Initialize a dictionary to count
grouped_data = defaultdict(lambda: {
    "HeartDisease_Yes": 0, "HeartDisease_No": 0,
    "Stroke_Yes": 0, "Stroke_No": 0,
    "Diabetic_Yes": 0, "Diabetic_No": 0
})

# Group and count
for _, row in df.iterrows():
    age = row.get("AgeCategory", "Unknown")

    if row.get("HeartDisease") == "Yes":
        grouped_data[age]["HeartDisease_Yes"] += 1
    elif row.get("HeartDisease") == "No":
        grouped_data[age]["HeartDisease_No"] += 1

    if row.get("Stroke") == "Yes":
        grouped_data[age]["Stroke_Yes"] += 1
    elif row.get("Stroke") == "No":
        grouped_data[age]["Stroke_No"] += 1

    if row.get("Diabetic") == "Yes":
        grouped_data[age]["Diabetic_Yes"] += 1
    elif row.get("Diabetic") == "No":
        grouped_data[age]["Diabetic_No"] += 1

# Convert to a cleaned DataFrame
cleaned_df = pd.DataFrame([
    {"AgeCategory": age, **counts} for age, counts in grouped_data.items()
])

# Sort by AgeCategory 
cleaned_df = cleaned_df.sort_values(by="AgeCategory")

# Display for verification 
print(cleaned_df.head())
# Save to JSON
cleaned_df.to_json("cleaned_df.json", orient="records")
