// Global variable to store data
let dataGlobal = [];

// Set up the dimensions and margins of the graph
const margin = { top: 40, right: 30, bottom: 60, left: 60 };
const width = 850 - margin.left - margin.right;
const height = 500 - margin.top - margin.bottom;

// Create the SVG element
const svg = d3.select(".chart-svg")
  .attr("width", width + margin.left + margin.right)
  .attr("height", height + margin.top + margin.bottom)
  .append("g")
  .attr("transform", `translate(${margin.left},${margin.top})`);

// Create a tooltip div
const tooltip = d3.select("body")
  .append("div")
  .attr("class", "tooltip")
  .style("visibility", "hidden");

// Define all possible categories
const allCategories = [
  "HeartDisease_Yes", "HeartDisease_No", 
  "Stroke_Yes", "Stroke_No", 
  "Diabetic_Yes", "Diabetic_No"
];

// Define the color scale
const colorScale = d3.scaleOrdinal()
  .domain(allCategories)
  .range([
    "#e41a1c", "#fdae61", // HeartDisease Yes/No
    "#377eb8", "#abd9e9", // Stroke Yes/No
    "#4daf4a", "#a6d96a"  // Diabetic Yes/No
  ]);

// Function to update the chart based on selected condition
function updateChart(selectedCondition) {
  // Filter the data based on the selected condition
  let data;
  data = dataGlobal;

  // Clear the previous chart elements
  svg.selectAll("*").remove();

  // Define which categories to show based on selection
  let displayCategories;
  if (selectedCondition === "All") {
    displayCategories = allCategories;
  } else {
    displayCategories = [`${selectedCondition}_Yes`, `${selectedCondition}_No`];
  }

  // Create x scale
  const x0 = d3.scaleBand()
    .domain(data.map(d => d.AgeCategory))
    .rangeRound([0, width])
    .paddingInner(0.2);

  const x1 = d3.scaleBand()
    .domain(displayCategories)
    .rangeRound([0, x0.bandwidth()])
    .padding(0.05);

  // Find the maximum value for the y scale
  const yMax = d3.max(data, d => {
    return d3.max(displayCategories, key => d[key]);
  });

  // Create y scale
  const y = d3.scaleLinear()
    .domain([0, yMax])
    .nice()
    .rangeRound([height, 0]);

  // Add X axis
  svg.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(d3.axisBottom(x0))
    .selectAll("text")
    .style("text-anchor", "end")
    .attr("dx", "-.8em")
    .attr("dy", ".15em")
    .attr("transform", "rotate(-45)")
    .style("font-size", "12px");

  // Add X axis label
  svg.append("text")
    .attr("class", "axis-label")
    .attr("text-anchor", "middle")
    .attr("x", width / 2)
    .attr("y", height + margin.bottom - 10)
    .text("Age Group");

  // Add Y axis
  svg.append("g")
    .call(d3.axisLeft(y).ticks(10))
    .selectAll("text")
    .style("font-size", "12px");

  // Add Y axis label
  svg.append("text")
    .attr("class", "axis-label")
    .attr("text-anchor", "middle")
    .attr("transform", "rotate(-90)")
    .attr("x", -height / 2)
    .attr("y", -margin.left + 15)
    .text("Count");

  // Add the bars
  svg.append("g")
    .selectAll("g")
    .data(data)
    .join("g")
    .attr("transform", d => `translate(${x0(d.AgeCategory)},0)`)
    .selectAll("rect")
    .data(d => displayCategories.map(key => ({
      key: key,
      value: d[key],
      age: d.AgeCategory
    })))
    .join("rect")
    .attr("class", "bar")
    .attr("x", d => x1(d.key))
    .attr("y", d => y(d.value))
    .attr("width", x1.bandwidth())
    .attr("height", d => height - y(d.value))
    .attr("fill", d => colorScale(d.key))
    .on("mouseover", function(event, d) {
      d3.select(this).attr("opacity", 0.8);
      
      // Format the key for display (e.g., "HeartDisease_Yes" -> "Heart Disease: Yes")
      const [condition, status] = d.key.split('_');
      const formattedCondition = condition.replace(/([A-Z])/g, ' $1').trim();
      
      tooltip
        .style("visibility", "visible")
        .html(`<strong>${formattedCondition}</strong><br>Status: ${status}<br>Age: ${d.age}<br>Count: ${d.value.toLocaleString()}`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function() {
      d3.select(this).attr("opacity", 1);
      tooltip.style("visibility", "hidden");
    });

  // Add the legend
  const legendContainer = d3.select(".legend");
  legendContainer.html(""); // Clear previous legend

  displayCategories.forEach(category => {
    const legendItem = legendContainer.append("div")
      .attr("class", "legend-item");
    
    legendItem.append("div")
      .style("background-color", colorScale(category));
    
    // Format the category name for the legend
    const [condition, status] = category.split('_');
    legendItem.append("span")
      .text(`${condition} ${status}`);
  });
}

// Event listeners for the button slicers
document.getElementById("btn-all").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("All");
});

document.getElementById("btn-heart").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("HeartDisease");
});

document.getElementById("btn-stroke").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("Stroke");
});

document.getElementById("btn-diabetic").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("Diabetic");
});

// Helper function to set active button
function setActiveButton(activeButton) {
  document.querySelectorAll('.slicer-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  activeButton.classList.add('active');
}

// Load the data from JSON file
d3.json("../Data/Al_Amin.json").then(data => {
  dataGlobal = data;
  updateChart("All");
}).catch(error => {
  console.log("Error loading the JSON file:", error);
  // Fall back to sample data if JSON fails to load
  updateChart("All");
});

// Event listeners for the button slicers
document.getElementById("btn-all").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("All");
});

document.getElementById("btn-heart").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("HeartDisease");
});

document.getElementById("btn-stroke").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("Stroke");
});

document.getElementById("btn-diabetic").addEventListener("click", function() {
  setActiveButton(this);
  updateChart("Diabetic");
});

// Helper function to set active button
function setActiveButton(activeButton) {
  document.querySelectorAll('.slicer-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  activeButton.classList.add('active');
}