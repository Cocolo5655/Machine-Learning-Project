// Global variables
let pieData = [];
let originalData = [];
let svg;
let arc;
let pie;
let color;
let total = 0;
let showPercentages = true;

// Set up dimensions
const width = 600;
const height = 400;
const radius = Math.min(width, height) / 2 - 40;

// Initialize D3 elements
function initializeChart() {
    // Clear any existing SVG
    d3.select("#chart svg").remove();
    
    // Create new SVG
    svg = d3.select("#chart")
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", `translate(${width/2},${height/2})`);
        
    // Create color scale
    color = d3.scaleOrdinal()
        .domain(pieData.map(d => d.name))
        .range(["#ff6b6b", "#4ecdc4", "#ff9999", "#95e1d3"]);
        
    // Create pie generator
    pie = d3.pie()
        .value(d => d.value)
        .sort(null);
        
    // Create arc generator
    arc = d3.arc()
        .innerRadius(0)
        .outerRadius(radius);
}

// Load CSV data
d3.csv("../Data/Obinna.csv").then(function(dataset) {
    // Process the dataset
    const summary = {
        "Smokers with Heart Disease": 0,
        "Smokers without Heart Disease": 0,
        "Non-smokers with Heart Disease": 0,
        "Non-smokers without Heart Disease": 0
    };

    dataset.forEach(d => {
        if (d.Smoking === "Yes" && d.HeartDisease === "Yes") {
            summary["Smokers with Heart Disease"]++;
        } else if (d.Smoking === "Yes" && d.HeartDisease === "No") {
            summary["Smokers without Heart Disease"]++;
        } else if (d.Smoking === "No" && d.HeartDisease === "Yes") {
            summary["Non-smokers with Heart Disease"]++;
        } else if (d.Smoking === "No" && d.HeartDisease === "No") {
            summary["Non-smokers without Heart Disease"]++;
        }
    });

    // Convert summary to array for D3
    originalData = Object.entries(summary).map(([name, value]) => ({ name, value }));
    pieData = [...originalData];
    total = dataset.length;
    
    // Initialize and render the chart
    initializeChart();
    updateChart();
    
    // Set up event listeners for buttons
    setupEventListeners();
    
}).catch(function(error) {
    console.error("Error loading the CSV file:", error);
    alert("Error loading the CSV file. Please make sure the file is in the correct location and you're running a local server.");
});

// Update the chart based on current data selection
function updateChart() {
    // Initialize chart if needed
    if (!svg) {
        initializeChart();
    }
    
    // Clear existing elements
    svg.selectAll(".arc").remove();
    d3.select(".legend").remove();
    
    // Generate updated pie chart
    const arcs = svg.selectAll(".arc")
        .data(pie(pieData))
        .enter()
        .append("g")
        .attr("class", "arc");
        
    // Draw pie slices
    arcs.append("path")
        .attr("d", arc)
        .attr("fill", d => color(d.data.name))
        .attr("stroke", "white")
        .attr("stroke-width", 2);
        
    // Add labels if there are values to show
    if (showPercentages) {
        const labelArc = d3.arc()
            .innerRadius(radius * 0.5) // Moved labels inward slightly
            .outerRadius(radius * 0.7);
            
        arcs.append("text")
            .attr("transform", d => {
                // Only show label if segment is large enough
                return d.data.value / total > 0.03 ? 
                   `translate(${labelArc.centroid(d)})` : null;
            })
            .attr("text-anchor", "middle")
            .text(d => {
                // Only show text if segment is large enough
                return d.data.value / total > 0.03 ? 
                   `${((d.data.value / total) * 100).toFixed(1)}%` : "";
            })
            .style("font-size", "12px")
            .style("font-weight", "bold")
            .style("fill", "black");
    }
    
    // Set up tooltip interaction
    const tooltip = d3.select("#tooltip");
    
    arcs.on("mouseover", function(event, d) {
        tooltip.style("opacity", 1)
            .html(`${d.data.name}: ${d.data.value} (${((d.data.value / total) * 100).toFixed(1)}%)`)
            .style("left", (event.pageX + 10) + "px")
            .style("top", (event.pageY - 10) + "px");
    })
    .on("mouseout", function() {
        tooltip.style("opacity", 0);
    });
    
    // Add legend
    // First remove any existing legend
    d3.select(".legend").remove();
    
    // Create legend in a completely separate container
    const legend = d3.select("#legend-container")
        .append("div")
        .attr("class", "legend");
        
    legend.selectAll("div")
        .data(pieData)
        .enter()
        .append("div")
        .html(d => `
            <span class="legend-color" style="background-color:${color(d.name)}"></span>
            ${d.name}: ${d.value.toLocaleString()} (${((d.value / total) * 100).toFixed(1)}%)
        `);
}

// Set up button event listeners
function setupEventListeners() {
    // Button click handlers
    document.getElementById("btn-all").addEventListener("click", function() {
        setActiveButton(this);
        // Reset to original full data
        pieData = [...originalData];
        updateChart();
    });
    
    document.getElementById("btn-smokers").addEventListener("click", function() {
        setActiveButton(this);
        // Filter to show only smokers data
        pieData = originalData.filter(d => 
            d.name === "Smokers with Heart Disease" || 
            d.name === "Smokers without Heart Disease"
        );
        updateChart();
    });
    
    document.getElementById("btn-nonsmokers").addEventListener("click", function() {
        setActiveButton(this);
        // Filter to show only non-smokers data
        pieData = originalData.filter(d => 
            d.name === "Non-smokers with Heart Disease" || 
            d.name === "Non-smokers without Heart Disease"
        );
        updateChart();
    });
    
    document.getElementById("btn-heartdisease").addEventListener("click", function() {
        setActiveButton(this);
        // Filter to show only heart disease data
        pieData = originalData.filter(d => 
            d.name === "Smokers with Heart Disease" || 
            d.name === "Non-smokers with Heart Disease"
        );
        updateChart();
    });
    
    document.getElementById("btn-percentage").addEventListener("click", function() {
        // Toggle this button independently of the others
        this.classList.toggle("active");
        showPercentages = this.classList.contains("active");
        updateChart();
    });
}

// Helper function to set active button
function setActiveButton(activeButton) {
    // Skip percentage button which operates independently
    if (activeButton.id === "btn-percentage") return;
    
    // Get all data filter buttons (excluding the percentage toggle)
    const filterButtons = [
        document.getElementById("btn-all"),
        document.getElementById("btn-smokers"),
        document.getElementById("btn-nonsmokers"),
        document.getElementById("btn-heartdisease")
    ];
    
    // Remove active class from all buttons
    filterButtons.forEach(btn => {
        btn.classList.remove("active");
    });
    
    // Add active class to clicked button
    activeButton.classList.add("active");
}