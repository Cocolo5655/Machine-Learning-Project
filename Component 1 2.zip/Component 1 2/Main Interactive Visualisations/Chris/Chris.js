// Show loading indicator
const loadingIndicator = document.querySelector('.loading');

// Variables to store state
let originalData = [];
let currentData = [];
let overallAverages = {};
let selectedBar = null;
let currentZoom = 1;

// Pre-aggregate function to reduce data size
function aggregateData(rawData) {
    // Create summary objects for "Yes" and "No" heart disease
    const summary = {
        "Yes": { BMI: 0, PhysicalHealth: 0, MentalHealth: 0, count: 0 },
        "No": { BMI: 0, PhysicalHealth: 0, MentalHealth: 0, count: 0 }
    };
    
    // Aggregate values
    rawData.forEach(d => {
        const group = d.HeartDisease;
        if (group === "Yes" || group === "No") {
            summary[group].BMI += +d.BMI || 0;
            summary[group].PhysicalHealth += +d.PhysicalHealth || 0;
            summary[group].MentalHealth += +d.MentalHealth || 0;
            summary[group].count++;
        }
    });
    
    // Calculate averages and format for D3
    return [
        {
            HeartDisease: "Yes", 
            BMI: summary["Yes"].BMI / summary["Yes"].count,
            PhysicalHealth: summary["Yes"].PhysicalHealth / summary["Yes"].count,
            MentalHealth: summary["Yes"].MentalHealth / summary["Yes"].count
        },
        {
            HeartDisease: "No", 
            BMI: summary["No"].BMI / summary["No"].count,
            PhysicalHealth: summary["No"].PhysicalHealth / summary["No"].count,
            MentalHealth: summary["No"].MentalHealth / summary["No"].count
        }
    ];
}

// Calculate overall averages for each metric
function calculateAverages(data) {
    const totals = { BMI: 0, PhysicalHealth: 0, MentalHealth: 0 };
    const count = data.length;
    
    data.forEach(d => {
        totals.BMI += d.BMI;
        totals.PhysicalHealth += d.PhysicalHealth;
        totals.MentalHealth += d.MentalHealth;
    });
    
    return {
        BMI: totals.BMI / count,
        PhysicalHealth: totals.PhysicalHealth / count,
        MentalHealth: totals.MentalHealth / count
    };
}

// Load and process the dataset
d3.json("../Data/Chris.json").then(rawData => {
    try {
        // Pre-aggregate data for faster rendering
        originalData = aggregateData(rawData);
        // Create a deep copy to avoid reference issues
        currentData = JSON.parse(JSON.stringify(originalData));
        overallAverages = calculateAverages(currentData);
        
        console.log("Data loaded:", originalData);
        console.log("Averages:", overallAverages);
        
        // Hide loading indicator
        loadingIndicator.style.display = 'none';
        
        // Chart setup
        const width = 850, height = 500;
        const margin = { top: 50, right: 120, bottom: 70, left: 80 };
        const svg = d3.select("svg");
        const tooltip = d3.select(".tooltip");
        
        // Add a group for zoom
        const chartGroup = svg.append("g")
            .attr("class", "chart-group");

        // Define categories and color scale
        const categories = ["BMI", "PhysicalHealth", "MentalHealth"];
        const color = d3.scaleOrdinal()
            .domain(categories)
            .range(["#1f77b4", "#ff7f0e", "#2ca02c"]);

        // Fixed X scale
        const x = d3.scaleBand()
            .domain(currentData.map(d => d.HeartDisease))
            .range([margin.left, width - margin.right])
            .padding(0.4);

        // Dynamic Y scale
        const y = d3.scaleLinear()
            .range([height - margin.bottom, margin.top]);
            
        
        // Generate insights function
        function generateInsights(d, category) {
            const value = d.data[category];
            const hdStatus = d.data.HeartDisease;
            const avg = overallAverages[category];
            const diff = value - avg;
            const comparedToAvg = diff > 0 ? 'higher' : 'lower';
            
            // Simplified two-line insight
            return `
                <p><strong>${category}:</strong> ${value.toFixed(2)} for people ${hdStatus === 'Yes' ? 'with' : 'without'} heart disease</p>
                <p>This is ${comparedToAvg} than the overall average of ${avg.toFixed(2)}</p>
            `;
        }

        // Render function with optimization
        function update(selectedCategory, animate = false) {
            console.log("Updating chart with:", selectedCategory);
            console.log("Current data:", currentData);
            
            // Clear previous chart elements for clean render
            chartGroup.selectAll(".bar-group").remove();
            chartGroup.selectAll(".axis").remove();
            chartGroup.selectAll(".axis-label").remove();
            
            // Filter categories based on selection
            const filteredCategories = selectedCategory === "All" ? 
                categories : [selectedCategory];
            
            // Stack data
            const stackGenerator = d3.stack().keys(filteredCategories);
            const stackedData = stackGenerator(currentData);
            
            console.log("Stacked data:", stackedData);

            // Set Y domain with padding
            const maxValue = d3.max(stackedData, layer => d3.max(layer, d => d[1]));
            y.domain([0, maxValue * 1.1]).nice();

            // Create bar groups
            const barGroups = chartGroup.selectAll(".bar-group")
                .data(stackedData)
                .enter().append("g")
                .attr("class", "bar-group")
                .style("fill", d => color(d.key));

            // Add bars with optimized rendering
            const bars = barGroups.selectAll("rect")
                .data(d => d)
                .enter().append("rect")
                .attr("class", "bar")
                .attr("x", d => x(d.data.HeartDisease))
                .attr("width", x.bandwidth())
                .attr("stroke", "#333")
                .attr("stroke-width", 0.5)
                .on("mouseover", function(event, d) {
                    const category = d3.select(this.parentNode).datum().key;
                    const value = d.data[category].toFixed(2);
                    tooltip.style("visibility", "visible")
                        .html(`<strong>${category}</strong><br>
                               Value: ${value}<br>
                               Heart Disease: ${d.data.HeartDisease}`);
                    d3.select(this).style("opacity", 0.7);
                })
                .on("mousemove", function(event) {
                    tooltip.style("top", (event.pageY - 40) + "px")
                        .style("left", (event.pageX + 10) + "px");
                })
                .on("mouseout", function() {
                    tooltip.style("visibility", "hidden");
                    d3.select(this).style("opacity", 1);
                })
                .on("click", function(event, d) {
                    event.stopPropagation();
                    
                    // Reset previous selection
                    chartGroup.selectAll(".bar").classed("selected", false).style("stroke-width", 0.5);
                    
                    // Set new selection
                    d3.select(this).classed("selected", true).style("stroke-width", 3);
                    
                    // Get category and generate insights
                    const category = d3.select(this.parentNode).datum().key;
                    document.getElementById('insights-content').innerHTML = generateInsights(d, category);
                    
                    // Store reference to selected bar
                    selectedBar = this;
                });
            
            // Animate if requested, otherwise set directly
            if (animate) {
                bars.attr("y", height - margin.bottom)
                    .attr("height", 0)
                    .transition()
                    .duration(500)
                    .attr("y", d => y(d[1]))
                    .attr("height", d => y(d[0]) - y(d[1]));
            } else {
                bars.attr("y", d => y(d[1]))
                    .attr("height", d => y(d[0]) - y(d[1]));
            }

            // Add axes
            chartGroup.append("g")
                .attr("class", "axis x-axis")
                .attr("transform", `translate(0,${height - margin.bottom})`)
                .call(d3.axisBottom(x))
                .selectAll("text")
                .style("font-weight", "bold");
            
            chartGroup.append("g")
                .attr("class", "axis y-axis")
                .attr("transform", `translate(${margin.left},0)`)
                .call(d3.axisLeft(y));
            
            // Add axis labels
            chartGroup.append("text")
                .attr("class", "axis-label")
                .attr("x", width / 2)
                .attr("y", height - margin.bottom/3)
                .style("text-anchor", "middle")
                .text("Heart Disease Status");
            
            chartGroup.append("text")
                .attr("class", "axis-label")
                .attr("transform", "rotate(-90)")
                .attr("x", -height / 2)
                .attr("y", margin.left / 2.5)
                .style("text-anchor", "middle")
                .text("Average Value");

            // Update legend
            updateLegend(filteredCategories);
        }

        // Legend update function
        function updateLegend(filteredCategories) {
            const legendContainer = d3.select(".legend");
            legendContainer.selectAll("*").remove();

            legendContainer.selectAll(".legend-item")
                .data(filteredCategories)
                .enter().append("div")
                .attr("class", "legend-item")
                .html(d => `<div style="background-color: ${color(d)}"></div><span>${d}</span>`);
        }
        
        // Zoom functionality
        function zoom(zoomIn) {
            if (zoomIn) {
                currentZoom *= 1.2;
            } else {
                currentZoom /= 1.2;
            }
            
            // Limit zoom level
            currentZoom = Math.max(0.5, Math.min(currentZoom, 3));
            
            // Apply zoom transform
            chartGroup.attr("transform", `scale(${currentZoom})`);
            
            // Adjust SVG viewBox to center content
            const viewBoxWidth = width / currentZoom;
            const viewBoxHeight = height / currentZoom;
            const viewBoxX = (width - viewBoxWidth) / 2;
            const viewBoxY = (height - viewBoxHeight) / 2;
            
            svg.attr("viewBox", `${viewBoxX} ${viewBoxY} ${viewBoxWidth} ${viewBoxHeight}`);
        }
        
        // Reset view function
        function resetView() {
            currentZoom = 1;
            chartGroup.attr("transform", "scale(1)");
            svg.attr("viewBox", `0 0 ${width} ${height}`);
            
            // Reset filters
            document.querySelectorAll('.metric-filter').forEach(filter => {
                filter.classList.remove('active');
            });
            document.querySelector('.metric-filter[data-category="All"]').classList.add('active');
            
            // Reset insights
            document.getElementById('insights-content').innerHTML = 'Click on a bar to see detailed insights';
            
            // Update chart
            update('All', true);
        }

        // Event listeners for metric filters
        document.querySelectorAll('.metric-filter').forEach(filter => {
            filter.addEventListener('click', function() {
                // Remove active class from all filters
                document.querySelectorAll('.metric-filter').forEach(item => {
                    item.classList.remove('active');
                });
                
                // Add active class to clicked filter
                this.classList.add('active');
                
                // Update chart with selected category
                update(this.dataset.category, true);
            });
        });
        
        // Zoom controls
        document.getElementById('zoom-in').addEventListener('click', () => zoom(true));
        document.getElementById('zoom-out').addEventListener('click', () => zoom(false));
        
        // Reset view
        document.getElementById('reset-view').addEventListener('click', resetView);
        
        // Click outside to deselect
        svg.on("click", function(event) {
            if (event.target === this) {
                chartGroup.selectAll(".bar").classed("selected", false).style("stroke-width", 0.5);
                document.getElementById('insights-content').innerHTML = 'Click on a bar to see detailed insights';
                selectedBar = null;
            }
        });

        // Initial render
        update("All", true);
        
    } catch (error) {
        console.error("Error processing data:", error);
        loadingIndicator.textContent = "Error processing data. Check console for details.";
    }
}).catch(error => {
    console.error("Error loading JSON:", error);
    loadingIndicator.textContent = "Error loading data. Please check console.";
});