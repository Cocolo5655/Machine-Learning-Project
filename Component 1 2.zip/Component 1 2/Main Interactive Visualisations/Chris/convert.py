# Code to convert csv to json
import csv
import json
import os

def convert_csv_to_json(csv_file_path, json_file_path):
    # Check if the CSV file exists
    if not os.path.exists(csv_file_path):
        raise FileNotFoundError(f"The file {csv_file_path} does not exist.")

    # Read the CSV file and convert it to JSON
    with open(csv_file_path, mode='r', encoding='utf-8') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        data = [row for row in csv_reader]

    # Write the JSON data to a file
    with open(json_file_path, mode='w', encoding='utf-8') as json_file:
        json.dump(data, json_file, indent=4)
        
if __name__ == "__main__":
    # Example usage
    csv_file_path = 'heart_disease (1).csv'  # Path to your CSV file
    json_file_path = 'data.json'  # Path to save the JSON file

    try:
        convert_csv_to_json(csv_file_path, json_file_path)
        print(f"Successfully converted {csv_file_path} to {json_file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")