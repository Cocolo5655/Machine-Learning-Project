// Global variable to store data
let dataGlobal = [];
let lineData = [];

// Set the dimensions and margins of the graph
const margin = { top: 40, right: 30, bottom: 50, left: 60 },
    width = 750 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom;

// Append the SVG object to the div with ID "my_chart"
const svg = d3.select("#my_chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

// Tooltip div
const tooltip = d3.select("#tooltip");

// Load the data
d3.csv("../Data/Kelvin.csv").then(function (data) {
    // Store data globally
    dataGlobal = data;
    
    // Parse numeric values
    data.forEach(d => {
        d.SleepTime = +d.SleepTime;
        d.BMI = +d.BMI;
    });

    // Group and process data
    const sumstat = d3.rollup(
        data,
        v => d3.sum(v, leaf => leaf.BMI),
        d => d.GenHealth,
        d => d.SleepTime
    );

    lineData = Array.from(sumstat, ([genHealth, sleepTimeMap]) => ({
        genHealth: genHealth,
        values: Array.from(sleepTimeMap, ([sleepTime, sumBMI]) => ({
            SleepTime: sleepTime,
            SumBMI: sumBMI
        })).sort((a, b) => d3.ascending(a.SleepTime, b.SleepTime))
    }));

    // X axis
    const x = d3.scaleLinear()
        .domain(d3.extent(data, d => d.SleepTime))
        .range([0, width]);

    svg.append("g")
        .attr("transform", `translate(0, ${height})`)
        .call(d3.axisBottom(x).ticks(10).tickFormat(d3.format("d")))
        .attr("font-size", "12px");

    // Y axis
    const y = d3.scaleLinear()
        .domain([0, d3.max(lineData, group => d3.max(group.values, d => d.SumBMI)) * 1.1])
        .range([height, 0]);

    svg.append("g")
        .call(d3.axisLeft(y).ticks(8).tickFormat(d => `${Math.floor(d/1000)}k`))
        .attr("font-size", "12px");

    // Color palette
    const color = d3.scaleOrdinal()
        .domain(lineData.map(d => d.genHealth))
        .range(d3.schemeCategory10);

    // Axis labels
    svg.append("text")
        .attr("transform", `translate(${width / 2}, ${height + margin.bottom - 10})`)
        .style("text-anchor", "middle")
        .text("Sleep Time")
        .attr("font-size", "14px")
        .attr("font-weight", "bold");

    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left)
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("Sum of BMI")
        .attr("font-size", "14px")
        .attr("font-weight", "bold");
        
    // Function to update the chart
    window.updateChart = function(selectedGenHealth, animate = false) {
        const filteredData = selectedGenHealth === "all" ? 
            lineData : 
            lineData.filter(d => d.genHealth === selectedGenHealth);
            
        console.log("Updating chart with:", selectedGenHealth);
        console.log("Filtered data:", filteredData);

        const lines = svg.selectAll(".line")
            .data(filteredData, d => d.genHealth);

        const paths = lines.join("path")
            .attr("class", "line")
            .attr("fill", "none")
            .attr("stroke", d => color(d.genHealth))
            .attr("stroke-width", 2)
            .attr("d", d => d3.line()
                .x(d => x(d.SleepTime))
                .y(d => y(d.SumBMI))(d.values)
            );

        if (animate) {
            paths.attr("stroke-dasharray", function () {
                const length = this.getTotalLength();
                return `${length} ${length}`;
            })
            .attr("stroke-dashoffset", function () {
                return this.getTotalLength();
            })
            .transition()
            .duration(6000)
            .ease(d3.easeLinear)
            .attr("stroke-dashoffset", 0);
        }

        lines.exit().remove();
    };

    // Initial rendering
    window.updateChart("all");

    // Play button event
    const playButton = d3.select("#playButton");
    playButton.on("click", function () {
        // Get the currently active filter
        const activeBtn = document.querySelector('.slicer-btn.active:not(#playButton)');
        let selectedGenHealth = "all";
        
        if (activeBtn) {
            if (activeBtn.id === 'btn-all') selectedGenHealth = "all";
            else if (activeBtn.id === 'btn-excellent') selectedGenHealth = "Excellent";
            else if (activeBtn.id === 'btn-verygood') selectedGenHealth = "Very good";
            else if (activeBtn.id === 'btn-good') selectedGenHealth = "Good";
            else if (activeBtn.id === 'btn-fair') selectedGenHealth = "Fair";
            else if (activeBtn.id === 'btn-poor') selectedGenHealth = "Poor";
        }
        
        window.updateChart(selectedGenHealth, true);
    });
}).catch(function (error) {
    console.error("Error loading or processing data:", error);
});

// Add event listener for slicer buttons
document.addEventListener('DOMContentLoaded', function() {
    // Set up button click handlers after DOM is loaded
    setupButtonHandlers();
});

function setupButtonHandlers() {
    // Add click event listeners to all slicer buttons
    const slicerButtons = document.querySelectorAll('.slicer-btn');
    
    slicerButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Skip the play button
            if (this.id === 'playButton') return;
            
            // Remove active class from all buttons
            slicerButtons.forEach(btn => {
                if (btn.id !== 'playButton') {
                    btn.classList.remove('active');
                }
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Determine which GenHealth value to filter by
            let selectedGenHealth = "all";
            
            if (this.id === 'btn-all') selectedGenHealth = "all";
            else if (this.id === 'btn-excellent') selectedGenHealth = "Excellent";
            else if (this.id === 'btn-verygood') selectedGenHealth = "Very good";
            else if (this.id === 'btn-good') selectedGenHealth = "Good";
            else if (this.id === 'btn-fair') selectedGenHealth = "Fair";
            else if (this.id === 'btn-poor') selectedGenHealth = "Poor";
            
            console.log("Button clicked:", this.id);
            console.log("Selected GenHealth:", selectedGenHealth);
            
            // Check if updateChart is available yet
            if (window.updateChart) {
                window.updateChart(selectedGenHealth);
            } else {
                console.error("updateChart function not available yet");
            }
        });
    });
}