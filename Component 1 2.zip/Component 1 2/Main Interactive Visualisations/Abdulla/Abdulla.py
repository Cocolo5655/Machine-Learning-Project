import pandas as pd
import json

# Load data
df = pd.read_csv("heart_disease_2.csv")

# Create BMI category based on ranges
bins = [0, 18.5, 24.9, 29.9, 34.9, 39.9, float("inf")]
labels = ["Underweight", "Normal", "Overweight", "Obese I", "Obese II", "Obese III"]
df["BMI_Category"] = pd.cut(df["BMI"], bins=bins, labels=labels)

# Define the hierarchy levels
levels = ["Sex", "HeartDisease", "Race", "GenHealth", "BMI_Category"]

# Build hierarchical structure
def build_hierarchy(data, levels):
    root = {"name": "People", "children": []}
    for _, row in data.iterrows():
        current = root
        for level in levels:
            value = row[level]
            if "children" not in current:
                current["children"] = []
            children = current["children"]
            match = next((child for child in children if child["name"] == value), None)
            if match:
                current = match
            else:
                new_node = {"name": value}
                children.append(new_node)
                current = new_node
        # Add value and prepare AgeCategory and MentalHealth for filtering
        current["value"] = current.get("value", 0) + 1
        current["AgeCategory"] = row["AgeCategory"]  
        current["MentalHealth"] = row["MentalHealth"]
    return root

hierarchy = build_hierarchy(df, levels)

# Export to JSON
with open("decomposition_tree_complete_2.json", "w") as f:
    json.dump(hierarchy, f, indent=2)