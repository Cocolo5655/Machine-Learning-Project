// Global filter settings
let activeFilters = {
  heartdisease: 'all',
  race: 'all',
  weightCategory: 'all'
};

// Data storage variables
let originalData = null;
let filteredData = null;
let rootNode = null;

// BMI reference values for weight categories
const weightToBMI = {
  "Underweight": 17.5,  // Average BMI for underweight (< 18.5)
  "Normal": 22.0,       // Average BMI for normal weight (18.5-24.9)
  "Overweight": 27.5,   // Average BMI for overweight (25.0-29.9)
  "Obese I": 32.5,      // Average BMI for obese class I (30.0-34.9)
  "Obese II": 37.5,     // Average BMI for obese class II (35.0-39.9)
  "Obese III": 42.5     // Average BMI for obese class III (≥ 40.0)
};

// Load data when document is ready
fetch('../Data/Abdulla.json')
  .then(resp => resp.json())
  .then(data => {
    originalData = JSON.parse(JSON.stringify(data));
    filteredData = data;
    buildTree(data);
    setupFilterListeners();
  });

//------------------------------------------------
// Listeners for filter buttons and reset functionality
//------------------------------------------------
// Purpose: Sets up event listeners for filter buttons and reset functionality

function setupFilterListeners() {
  // Configure slicer buttons
  const slicerButtons = document.querySelectorAll('.slicer-btn');
  slicerButtons.forEach(button => {
    button.addEventListener('click', function() {
      const filterType = this.getAttribute('data-filter');
      const filterValue = this.getAttribute('data-value');
      
      // Update button states in the filter group
      const groupButtons = document.querySelectorAll(`.slicer-btn[data-filter="${filterType}"]`);
      groupButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Update active filter and apply
      activeFilters[filterType] = filterValue;
      applyFilters();
    });
  });
  
  // Configure reset button
  const resetButton = document.getElementById('resetFilters');
  if (resetButton) {
    resetButton.addEventListener('click', function() {
      // Reset all filter values to default
      activeFilters = {
        heartdisease: 'all',
        race: 'all',
        weightCategory: 'all'
      };
      
      // Reset button visual states
      slicerButtons.forEach(button => {
        button.classList.toggle('active', button.getAttribute('data-value') === 'all');
      });
      
      applyFilters();
    });
  }
}

//------------------------------------------------
// Apple filters based on selection
//------------------------------------------------
// Purpose: Applies current filters and rebuilds the visualization

function applyFilters() {
  filteredData = filterData(originalData);
  
  // Clear and rebuild chart
  const chartDiv = document.getElementById('chart');
  chartDiv.innerHTML = '<div class="kpi-container" id="kpiContainer"></div>';
  buildTree(filteredData);
}

//------------------------------------------------
// Filter data based on active filters
//------------------------------------------------
// Purpose: Filters the data hierarchy based on active filters

function filterData(data) {
  // Create deep copy to avoid modifying original data
  const filteredData = JSON.parse(JSON.stringify(data));
  
  // Skip filtering if all options are set to 'all'
  if (activeFilters.heartdisease === 'all' && 
      activeFilters.race === 'all' && 
      activeFilters.weightCategory === 'all') {
    return filteredData;
  }
  
  // Apply hierarchical filtering
  filteredData.children.forEach(gender => {
    // Filter by heart disease status
    if (activeFilters.heartdisease !== 'all') {
      gender.children = gender.children.filter(heartDisease => 
        heartDisease.name === activeFilters.heartdisease
      );
    }
    
    gender.children.forEach(heartDisease => {
      // Filter by race
      if (activeFilters.race !== 'all') {
        heartDisease.children = heartDisease.children.filter(race => 
          race.name === activeFilters.race
        );
      }
      
      heartDisease.children.forEach(race => {
        race.children.forEach(genHealth => {
          // Filter by weight category
          if (activeFilters.weightCategory !== 'all') {
            genHealth.children = genHealth.children.filter(weight => 
              weight.name === activeFilters.weightCategory
            );
          }
        });
        
        // Remove empty general health categories
        race.children = race.children.filter(genHealth => genHealth.children.length > 0);
      });
      
      // Remove empty races
      heartDisease.children = heartDisease.children.filter(race => race.children.length > 0);
    });
    
    // Remove empty heart disease statuses
    gender.children = gender.children.filter(heartDisease => heartDisease.children.length > 0);
  });
  
  // Remove empty genders
  filteredData.children = filteredData.children.filter(gender => gender.children.length > 0);
  
  return filteredData;
}

//------------------------------------------------
// Calculate total count for each node
//------------------------------------------------
// Purpose: Calculates total count for each node in the hierarchy tree

function calculateTotalCount(node) {
  const children = node.children || node._children || [];

  // Recursively calculate total from children
  let total = 0;
  for (const child of children) {
    total += calculateTotalCount(child);
  }

  // Add this node's own value
  total += node.data.value || 0;
  
  // Store for later use
  node.data.totalCount = total;
  return total;
}

//------------------------------------------------
// Average BMI calculation for tooltips, KPI cards, and node labels
//------------------------------------------------
// Purpose: Calculates average BMI value for a node and its descendants

function calculateAverageBMI(node) {
  let totalBMI = 0;
  let totalCount = 0;
  
  function processNode(n) {
    if (!n) return;
    
    // Process leaf nodes with weight category data
    if (n.data.name && weightToBMI[n.data.name] && n.data.value) {
      totalBMI += weightToBMI[n.data.name] * n.data.value;
      totalCount += n.data.value;
    }
    
    // Process visible and collapsed children
    if (n.children) n.children.forEach(processNode);
    if (n._children) n._children.forEach(processNode);
  }
  
  processNode(node);
  return totalCount > 0 ? (totalBMI / totalCount).toFixed(1) : "N/A";
}

//------------------------------------------------
// Mental health calculation for tooltips, KPI cards, and node labels
//------------------------------------------------
// Purpose: Calculates average mental health value for a node and its descendants

function calculateAverageMentalHealth(node) {
  let totalMentalHealth = 0;
  let totalCount = 0;
  
  function processNode(n) {
    if (!n) return;
    
    // Process leaf nodes with mental health data
    if (n.data.MentalHealth !== undefined && n.data.value) {
      totalMentalHealth += n.data.MentalHealth * n.data.value;
      totalCount += n.data.value;
    }
    
    // Process visible and collapsed children
    if (n.children) n.children.forEach(processNode);
    if (n._children) n._children.forEach(processNode);
  }
  
  processNode(node);
  return totalCount > 0 ? (totalMentalHealth / totalCount).toFixed(1) : "N/A";
}

//------------------------------------------------
// Main function to build the tree visualization
//------------------------------------------------
// Purpose: Main function that builds the hierarchical tree visualization

function buildTree(data) {
  // Initialize visualization components
  createKPICards();
  
  const dx = 50; // Vertical spacing between nodes
  const dy = 550; // Horizontal spacing between hierarchy levels
  const width = 1200;
  let i = 0;

  // Configure D3 tree layout
  const tree = d3.tree().nodeSize([dx, dy]);
  const root = d3.hierarchy(data);
  rootNode = root; // Store reference for later access

  // Calculate node values
  calculateTotalCount(root);

  // Initialize tree positions
  tree(root);
  root.x0 = root.x;
  root.y0 = root.y;

  // Initial collapsing to level 3
  collapseBeyondLevel(root, 3);

  // Create SVG container
  const svgRoot = d3.select("#chart").append("svg")
    .attr("width", width)
    .attr("height", 460)
    .attr("preserveAspectRatio", "xMidYMid meet");

  const svg = svgRoot.append("g")
    .attr("transform", `translate(50,40)`);

  // Set up tooltip
  const tooltip = d3.select("#tooltip");
  
  // Prepare metrics for KPI cards
  const totalCount = root.data.totalCount;
  const avgBMI = calculateAverageBMI(root);
  const avgMentalHealth = calculateAverageMentalHealth(root);
  
  // Update KPI cards with calculated metrics
  updateKPICards(totalCount, avgBMI, avgMentalHealth);
  
  // Render initial tree
  update(root);

  // Set up control buttons
  document.getElementById('expandAll').addEventListener('click', function() {
    expandAll(root);
    update(root);
  });

  document.getElementById('collapseToLevel3').addEventListener('click', function() {
    expandAll(root); // Expand all first for consistent collapsing
    collapseBeyondLevel(root, 3);
    update(root);
  });

  //------------------------------------------------
  // Create KPI cards
  //------------------------------------------------
  // Purpose: Creates the KPI card containers

  function createKPICards() {
    const kpiContainer = document.getElementById('kpiContainer');
    
    // Create three KPI cards
    for (let i = 0; i < 3; i++) {
      const kpiCard = document.createElement('div');
      kpiCard.className = 'kpi-card';
      kpiCard.id = `kpiCard${i}`;
      
      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      kpiCard.appendChild(svg);
      kpiContainer.appendChild(kpiCard);
    }
  }

  //------------------------------------------------
  // Update KPICards
  //------------------------------------------------
  // Purpose: Updates KPI cards with current metrics

  function updateKPICards(totalCount, avgBMI, avgMentalHealth) {
    // KPI 1: Total People
    const kpi1Svg = d3.select("#kpiCard0 svg");
    kpi1Svg.selectAll("*").remove();
    
    // Background
    kpi1Svg.append("rect")
      .attr("width", "100%")
      .attr("height", "100%")
      .attr("fill", "#0078D4");
    
    // Title
    kpi1Svg.append("text")
      .attr("x", 15)
      .attr("y", 30)
      .attr("fill", "white")
      .style("font-size", "16px")
      .style("font-weight", "bold")
      .text("Total People");
    
    // Value
    kpi1Svg.append("text")
      .attr("x", 15)
      .attr("y", 70)
      .attr("fill", "white")
      .style("font-size", "28px")
      .style("font-weight", "bold")
      .text(totalCount ? totalCount.toLocaleString() : "0");
    
    // KPI 2: Average BMI
    const kpi2Svg = d3.select("#kpiCard1 svg");
    kpi2Svg.selectAll("*").remove();
    
    // Background
    kpi2Svg.append("rect")
      .attr("width", "100%")
      .attr("height", "100%")
      .attr("fill", "#5B9BD5");
    
    // Title
    kpi2Svg.append("text")
      .attr("x", 15)
      .attr("y", 30)
      .attr("fill", "white")
      .style("font-size", "16px")
      .style("font-weight", "bold")
      .text("Average BMI");
    
    // Value
    kpi2Svg.append("text")
      .attr("x", 15)
      .attr("y", 70)
      .attr("fill", "white")
      .style("font-size", "28px")
      .style("font-weight", "bold")
      .text(avgBMI);
    
    // KPI 3: Average Mental Health
    const kpi3Svg = d3.select("#kpiCard2 svg");
    kpi3Svg.selectAll("*").remove();
    
    // Background
    kpi3Svg.append("rect")
      .attr("width", "100%")
      .attr("height", "100%")
      .attr("fill", "#8064A2");
    
    // Title
    kpi3Svg.append("text")
      .attr("x", 15)
      .attr("y", 30)
      .attr("fill", "white")
      .style("font-size", "16px")
      .style("font-weight", "bold")
      .text("Avg Mental Health");
    
    // Value
    kpi3Svg.append("text")
      .attr("x", 15)
      .attr("y", 70)
      .attr("fill", "white")
      .style("font-size", "28px")
      .style("font-weight", "bold")
      .text(avgMentalHealth);
    
    // Subtitle text
    kpi3Svg.append("text")
      .attr("x", 15)
      .attr("y", 90)
      .attr("fill", "rgba(255,255,255,0.8)")
      .style("font-size", "12px")
      .text("Scale: 1-30");
  }

  //------------------------------------------------
  // Expand all nodes
  //------------------------------------------------
  // Purpose: Expands all collapsed nodes in the tree

  function expandAll(node) {
    if (node._children) {
      node.children = node._children;
      node._children = null;
    }
    if (node.children) {
      node.children.forEach(expandAll);
    }
  }

  //------------------------------------------------
  // Collapse beyond to the specified level
  //------------------------------------------------
  // Purpose: Collapses all nodes beyond a specified depth level

  function collapseBeyondLevel(node, maxDepth) {
    if (node.depth >= maxDepth && node.children) {
      node._children = node.children;
      node.children = null;
    }
    if (node.children) {
      node.children.forEach(child => collapseBeyondLevel(child, maxDepth));
    }
  }

  //------------------------------------------------
  // Sort children nodes of the tree
  //------------------------------------------------
  // Purpose: Sorts children nodes based on specific criteria

  function sortChildren(node) {
    if (node.children) {
      // Check for health status children
      const hasHealthChildren = node.children.some(child => 
        ["Poor", "Fair", "Good", "Very good", "Excellent"].includes(child.data.name));
      
      // Sort races alphabetically
      if (node.depth === 2) {
        node.children.sort((a, b) => a.data.name.localeCompare(b.data.name));
      } 
      // Sort health statuses by natural order
      else if (hasHealthChildren) {
        node.children.sort((a, b) => {
          const healthOrder = {
            "Poor": 1, 
            "Fair": 2, 
            "Good": 3, 
            "Very good": 4, 
            "Excellent": 5
          };
          
          const orderA = healthOrder[a.data.name] || 999;
          const orderB = healthOrder[b.data.name] || 999;
          
          return orderA - orderB;
        });
      }
      // Sort other levels by value (largest first)
      else {
        node.children.sort((a, b) => (b.data.value || 0) - (a.data.value || 0));
      }
      
      // Recursively sort children
      node.children.forEach(sortChildren);
    }
    
    // Apply same logic to collapsed nodes
    if (node._children) {
      const hasHealthChildren = node._children.some(child => 
        ["Poor", "Fair", "Good", "Very good", "Excellent"].includes(child.data.name));
      
      if (node.depth === 2) {
        node._children.sort((a, b) => a.data.name.localeCompare(b.data.name));
      } 
      else if (hasHealthChildren) {
        node._children.sort((a, b) => {
          const healthOrder = {
            "Poor": 1, 
            "Fair": 2, 
            "Good": 3, 
            "Very good": 4, 
            "Excellent": 5
          };
          
          const orderA = healthOrder[a.data.name] || 999;
          const orderB = healthOrder[b.data.name] || 999;
          
          return orderA - orderB;
        });
      }
      else {
        node._children.sort((a, b) => (b.data.value || 0) - (a.data.value || 0));
      }
      
      node._children.forEach(sortChildren);
    }
  }

  //------------------------------------------------
  // Update function for tree visualization
  //------------------------------------------------
  // Purpose: Updates the tree visualization based on current state

  function update(source) {
    // Sort nodes for consistent display
    sortChildren(root);
    
    // Dynamic spacing adjustments
    const adjustedDx = d3.scaleLinear()
      .domain([0, 2])
      .range([40, 80]);
    
    const adjustedDy = d3.scaleLinear()
      .domain([0, 1])
      .range([140, 180]);
    
    tree.nodeSize([adjustedDx(root.depth), adjustedDy(root.depth)]);
    
    tree(root);

    const nodes = root.descendants();
    const links = root.links();
    
    // Clear and recreate level headers
    svg.selectAll(".level-header").remove();
    
    // Group nodes by depth level
    const nodesByDepth = {};
    nodes.forEach(node => {
      if (!nodesByDepth[node.depth]) {
        nodesByDepth[node.depth] = [];
      }
      nodesByDepth[node.depth].push(node);
    });
    
    // Create level headers
    Object.keys(nodesByDepth).forEach(depth => {
      const depthInt = parseInt(depth);
      if (depthInt > 4) return;
      
      let headerText = "";
      let headerColor = "#0275d8";
      
      switch(depthInt) {
        case 0: headerText = "TOTAL PEOPLE"; break;
        case 1: headerText = "GENDER"; break;
        case 2: headerText = "HEART DISEASE"; break;
        case 3: headerText = "RACE"; break;
        case 4: headerText = "GENERAL HEALTH"; break;
        default: headerText = "";
      }
      
      if (headerText && depthInt <= 4) {
        const leftmostNode = nodesByDepth[depth].reduce((min, node) => 
          (node.y < min.y) ? node : min, nodesByDepth[depth][0]);
        
        const xPos = leftmostNode.y;
        
        const topNode = nodesByDepth[depth].reduce((min, node) => 
          (node.x < min.x) ? node : min, nodesByDepth[depth][0]);
        
        svg.append("text")
          .attr("class", "level-header")
          .attr("x", xPos)
          .attr("y", topNode.x - 24)
          .attr("text-anchor", "start")
          .style("font-size", "13px")
          .style("font-weight", "bold")
          .style("text-decoration", "underline")
          .style("fill", headerColor) 
          .style("font-family", "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif")
          .text(headerText);
      }
    });
    
    // Calculate tree boundaries
    let left = root;
    let right = root;
    root.eachBefore(n => {
      if (n.x < left.x) left = n;
      if (n.x > right.x) right = n;
    });
    
    const transition = svg.transition().duration(500);
    
    // Calculate dynamic height
    const minHeight = 250;
    const height = Math.max(minHeight, right.x - left.x + adjustedDx(root.depth) * 2.5);
    const svgHeight = height + 120;
    
    const verticalOffset = (svgHeight - height) / 2 - left.x + 20;
    
    // Update SVG dimensions
    svgRoot.transition().duration(500)
      .attr("height", svgHeight);
    
    svg.transition().duration(500)
      .attr("transform", `translate(50,${verticalOffset})`);
    
    // Node handling
    const node = svg.selectAll("g.node")
      .data(nodes, d => d.id || (d.id = ++i));
    
    // Create new nodes
    const nodeEnter = node.enter().append("g")
      .attr("cursor", d => d.depth <= 1 ? "default" : "pointer")
      .attr("class", "node")
      .style("user-select", "none")
      .attr("transform", d => `translate(${source.y0},${source.x0})`)
      .on("click", (event, d) => {
        // Toggle children on click (except for top levels)
        if (d.depth <= 1) return;
    
        if (d.children) {
          d._children = d.children;
          d.children = null;
        } else {
          d.children = d._children;
          d._children = null;
        }
        update(d);
      })
      .on("mouseover", function(event, d) {
        // Prepare tooltip information
        let bmi = "N/A";
        let mentalHealth = "N/A";
        
        if (d.data.name && weightToBMI[d.data.name]) {
          bmi = weightToBMI[d.data.name].toFixed(1);
        }
        
        if (d.data.MentalHealth !== undefined) {
          mentalHealth = d.data.MentalHealth;
        }
        
        if (d.children || d._children) {
          bmi = calculateAverageBMI(d);
          mentalHealth = calculateAverageMentalHealth(d);
        }
        
        const tooltipContent = `
          <strong>${d.data.name}</strong><br>
          Count: ${d.data.value || d.data.totalCount || 0}<br>
          Avg BMI: ${bmi}<br>
          Avg Mental Health: ${mentalHealth}
        `;
        
        tooltip.html(tooltipContent)
          .style("left", (event.pageX + 15) + "px")
          .style("top", (event.pageY - 30) + "px")
          .style("opacity", 1);
      })
      .on("mouseout", function() {
        tooltip.style("opacity", 0);
      })
      .on("mousemove", function(event) {
        tooltip
          .style("left", (event.pageX + 15) + "px")
          .style("top", (event.pageY - 30) + "px");
      });
    
    const maxValue = d3.max(nodes, d => d.data.value || 0);
    
    // Create node rectangles
    nodeEnter.append("rect")
      .attr("fill", d => {
        if (d.data.name === "Normal") return "#A8D5BA";
        if (d.data.name === "Overweight") return "#FFE5A3";
        if (d.data.name === "Obese I") return "#FFB3A7";
        if (d.data.name === "Obese II") return "#FF9999";
        if (d.data.name === "Obese III") return "#D7BDE2";
        if (d.data.name === "Underweight") return "#A3D8F4";
        
        if (d.depth === 0) return "#3498db";
        if (d.depth === 1) return "#2980b9";
        if (d.depth === 2) return "#0078D4";
        return d._children ? '#0078D4' : '#0078D4';
      })
      .attr("x", 0)
      .attr("y", -12)
      .attr("width", d => {
        const minWidth = 125;
        const baseWidth = 80;
        const scaleWidth = 300;
        
        if (d.data.value) {
          return baseWidth + (d.data.value / maxValue) * scaleWidth;
        }
        
        return minWidth;
      })
      .attr("height", 32)
      .style("opacity", 0.9)
      .attr("rx", 4)
      .attr("ry", 4);
    
    // Add name labels
    nodeEnter.append("text")
      .attr("class", "node-name")
      .attr("text-anchor", "start")
      .attr("x", 6)
      .attr("dy", "0.32em")
      .attr("y", -1)
      .style("fill", d => {
        // Special colors for BMI categories
        if (d.data.name === "Normal") return "#2d5d3d";
        if (d.data.name === "Overweight") return "#996600";
        if (d.data.name === "Obese I") return "#8B3A3A";
        if (d.data.name === "Obese II") return "#800000";
        if (d.data.name === "Obese III") return "#4A235A";
        if (d.data.name === "Underweight") return "#154360";
        return 'white'; 
      })
      .style("font-weight", d => {
        return (d.depth <= 1 || d.data.name.includes("Obese") || 
                d.data.name === "Normal" || d.data.name === "Overweight" || 
                d.data.name === "Underweight") ? "bold" : "normal";
      })
      .style("font-size", d => d.depth <= 1 ? "13px" : "12px")
      .text(d => d.data.name);
    
    // Identify BMI categories
    const isBMICategory = name => ["Underweight", "Normal", "Overweight", "Obese I", "Obese II", "Obese III"].includes(name);
    
    // Add count values under label for non-BMI categories
    nodeEnter.filter(d => !isBMICategory(d.data.name))
      .append("text")
      .attr("class", "count-label")
      .attr("text-anchor", "start")
      .attr("x", 6)
      .attr("y", 16) // Positioned below name
      .style("font-size", "11px")
      .style("fill", "white")
      .style("font-weight", "bold")
      .text(d => d.data.totalCount || d.data.value || 0);
    
    // Add value labels for BMI categories only
    nodeEnter.filter(d => isBMICategory(d.data.name))
      .append("text")
      .attr("class", "value-label")
      .attr("text-anchor", "start")
      .attr("x", d => {
        const minWidth = 120;
        const baseWidth = 80;
        const scaleWidth = 300;
        
        const width = d.data.value 
          ? baseWidth + (d.data.value / maxValue) * scaleWidth
          : minWidth;
          
        return width + 6;
      })
      .attr("y", 4)
      .style("font-size", "13px")
      .style("fill", d => {
        if (d.data.name === "Normal") return "#2d5d3d";
        if (d.data.name === "Overweight") return "#996600";
        if (d.data.name === "Obese I") return "#8B3A3A";
        if (d.data.name === "Obese II") return "#800000";
        if (d.data.name === "Obese III") return "#4A235A";
        if (d.data.name === "Underweight") return "#154360";
        return '#333333';
      })
      .style("font-weight", "bold")
      .text(d => d.data.value || "");
    
    // Update node positions with animation
    const nodeUpdate = node.merge(nodeEnter).transition(transition)
      .attr("transform", d => `translate(${d.y},${d.x})`);
    
    // Remove exiting nodes with animation
    node.exit().transition(transition).remove()
      .attr("transform", d => `translate(${source.y},${source.x})`);
    
    // Links between nodes
    const link = svg.selectAll("path.link")
      .data(links, d => d.target.id);

    // Create new links with starting position
    link.enter().insert("path", "g")
      .attr("class", "link")
      .attr("d", d => {
        const o = { x: source.x0, y: source.y0 };
        return generateLinkPath(o, o);
      })
      .merge(link)
      .transition(transition)
      .attr("d", d => generateLinkPath(d.source, d.target));

    // Remove exiting links with animation
    link.exit().transition(transition).remove()
      .attr("d", d => {
        const o = { x: source.x, y: source.y };
        return generateLinkPath(o, o);
      });

    // Generate curved paths for links
    function generateLinkPath(source, target) {
      const minWidth = 120;
      const baseWidth = 80;
      const scaleWidth = 300;
      
      const sourceWidth = source.data && source.data.value 
        ? baseWidth + (source.data.value / maxValue) * scaleWidth
        : minWidth;
      
      const sourceX = source.y + sourceWidth;
      const sourceY = source.x;
      
      const targetX = target.y;
      const targetY = target.x;
      
      const midX = (sourceX + targetX) / 2;
      return `M${sourceX},${sourceY}
              C${midX},${sourceY}
              ${midX},${targetY}
              ${targetX},${targetY}`;
    }

    // Store positions for transitions
    nodes.forEach(d => {
      d.x0 = d.x;
      d.y0 = d.y;
    });
  }
}